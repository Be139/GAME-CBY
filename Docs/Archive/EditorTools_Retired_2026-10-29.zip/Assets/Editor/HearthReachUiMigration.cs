#if UNITY_EDITOR
using System;
using System.Linq;
using Michsky.UI.Reach;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

/// <summary>One-time Reach migration. Resulting objects remain directly editable in Prefab Mode.</summary>
public static class HearthReachUiMigration
{
    private const string Reach = "Assets/Reach - Complete Sci-Fi UI/";
    private static readonly Color Ink = new Color(.025f,.045f,.065f,1);
    private static readonly Color Teal = new Color(.24f,.80f,.84f,1);
    private static readonly Color Warm = new Color(.95f,.70f,.40f,1);
    public static string Apply()
    {
        if (EditorApplication.isPlaying) throw new InvalidOperationException("Stop Play before migrating UI.");
        var paths = AssetDatabase.FindAssets("t:Prefab", new[]{"Assets/Prefabs/UI/HearthHud/V2","Assets/Prefabs/UI/HearthSubtitle/V2"}).Select(AssetDatabase.GUIDToAssetPath).ToArray();
        var report = new System.Collections.Generic.List<string>();
        foreach (var path in paths)
        {
            var root = PrefabUtility.LoadPrefabContents(path);
            try
            {
                string[] before = root.GetComponentsInChildren<TMP_Text>(true).Select(t=>t.text).ToArray();
                ApplyRoot(root);
                string[] after = root.GetComponentsInChildren<TMP_Text>(true).Where(t=>!IsReach(t.transform)).Select(t=>t.text).ToArray();
                if (!before.SequenceEqual(after)) throw new InvalidOperationException("Content changed: "+path);
                PrefabUtility.SaveAsPrefabAsset(root,path);
                report.Add(path+" | Reach controls="+root.GetComponentsInChildren<ButtonManager>(true).Length+" | gradients="+root.GetComponentsInChildren<UIGradient>(true).Length);
            }
            finally { PrefabUtility.UnloadPrefabContents(root); }
        }
        AssetDatabase.SaveAssets();
        System.IO.File.WriteAllLines("Logs/HearthUiReview/reach-migration.txt",report);
        return string.Join("\n",report);
    }
    private static bool IsReach(Transform t)
    {
        for (;t!=null;t=t.parent) if(t.name.StartsWith("Reach_")) return true;
        return false;
    }
    public static void ApplyRoot(GameObject root)
    {
        var images = root.GetComponentsInChildren<Image>(true);
        var controls = root.GetComponentsInChildren<RectTransform>(true).Where(r=>
            r.GetComponent<Button>()!=null && r.rect.height<250 ||
            r.name=="Choice_A" || r.name=="Choice_B" || r.name=="ChoiceA" || r.name=="ChoiceB" || r.name=="RecallAction").ToArray();
        foreach (var r in controls) InstallControl(r);
        foreach(var img in images)
        {
            if(IsReach(img.transform)) continue;
            var r=img.rectTransform;
            string n=img.name;
            bool frame=img.sprite!=null && (img.sprite.name=="Cross Frame" || AssetDatabase.GetAssetPath(img.sprite).Contains("VectorParts"));
            bool surface= n=="PanelBackdrop" || n=="V2_PagePanel" || n=="Backdrop" || n=="ScreenSurface" || n=="V2_MenuSurface" || n.Contains("Backplate") || n=="V2_PhotoMetadata" || n=="HouseholdIntroduction" || n=="LilyMessagePanel";
            if(frame && r.rect.width>200 && r.rect.height>80)
            {
                img.sprite=AssetDatabase.LoadAssetAtPath<Sprite>(Reach+"Textures/Borders/Special/Cross Frame Alt.png");
                img.type=Image.Type.Sliced;
                img.color=new Color(Teal.r,Teal.g,Teal.b,.35f);
            }
            if(surface && img.color.a>.01f)
            {
                img.sprite=AssetDatabase.LoadAssetAtPath<Sprite>("Assets/UI/HEARTH/V2/ThirdParty/Reach/Square Filled.png");
                img.type=Image.Type.Sliced; img.color=Color.white;
                var gradient=img.GetComponent<UIGradient>();
                if(gradient==null) gradient=img.gameObject.AddComponent<UIGradient>();
                gradient.GradientType=UIGradient.Type.Horizontal;
                gradient.BlendMode=UIGradient.Blend.Multiply;
                gradient.EffectGradient=new Gradient{colorKeys=new[]{new GradientColorKey(Ink,0),new GradientColorKey(new Color(.055f,.10f,.13f,1),1)},alphaKeys=new[]{new GradientAlphaKey(1,0),new GradientAlphaKey(1,1)}};
                if(n!="ScreenSurface" && n!="V2_MenuSurface") AddRule(r,n=="LilyMessagePanel"?Warm:Teal);
            }
        }
        var typography=root.GetComponent<HearthUiTypography>();
        if(typography!=null)
        {
            foreach(var b in typography.Texts)
            {
                if(b.text==null)continue;
                if(b.role==HearthUiTextRole.Heading || b.role==HearthUiTextRole.Section)
                { b.text.characterSpacing=3; b.text.color=Teal; }
                if(b.role==HearthUiTextRole.Speaker) b.text.color=Warm;
            }
        }
    }
    private static void AddRule(RectTransform parent,Color color)
    {
        if(parent.Find("Reach_Accent")!=null)return;
        var go=new GameObject("Reach_Accent",typeof(RectTransform),typeof(Image));
        var rt=(RectTransform)go.transform;rt.SetParent(parent,false);
        rt.anchorMin=new Vector2(0,1);rt.anchorMax=new Vector2(0,1);rt.pivot=new Vector2(0,1);
        rt.anchoredPosition=new Vector2(0,-1);rt.sizeDelta=new Vector2(Mathf.Min(64,parent.rect.width*.12f),3);
        var image=go.GetComponent<Image>();image.color=color;image.raycastTarget=false;
    }
    private static void InstallControl(RectTransform target)
    {
        if(target.GetComponent<HearthReachControl>()!=null)return;
        var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(Reach+"Prefabs/UI Elements/Button/Button.prefab");
        var go=(GameObject)PrefabUtility.InstantiatePrefab(prefab);
        PrefabUtility.UnpackPrefabInstance(go,PrefabUnpackMode.Completely,InteractionMode.AutomatedAction);
        go.SetActive(false);go.name="Reach_Control";
        var rt=(RectTransform)go.transform;rt.SetParent(target,false);rt.SetAsFirstSibling();
        rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.offsetMin=Vector2.zero;rt.offsetMax=Vector2.zero;
        foreach(var tmp in go.GetComponentsInChildren<TMP_Text>(true)) UnityEngine.Object.DestroyImmediate(tmp.gameObject);
        foreach(var comp in go.GetComponentsInChildren<UIManagerImage>(true)) UnityEngine.Object.DestroyImmediate(comp);
        foreach(var layout in go.GetComponentsInChildren<HorizontalLayoutGroup>(true)) layout.enabled=false;
        foreach(var fitter in go.GetComponentsInChildren<ContentSizeFitter>(true)) fitter.enabled=false;
        var manager=go.GetComponent<ButtonManager>();
        manager.enableText=false;manager.enableIcon=false;manager.autoFitContent=false;manager.useCustomContent=true;
        manager.useSounds=false;manager.useLocalization=false;manager.useUINavigation=false;manager.checkForDoubleClick=false;
        manager.fadingMultiplier=10;manager.onClick.RemoveAllListeners();
        var cg=go.GetComponent<CanvasGroup>();
        if(cg==null) cg=go.AddComponent<CanvasGroup>();
        cg.blocksRaycasts=false;cg.interactable=false;
        foreach(var img in go.GetComponentsInChildren<Image>(true))
        {
            img.raycastTarget=false;
            if(img.name=="Icon") {img.enabled=false;continue;}
            bool highlight=img.GetComponentsInParent<Transform>(true).Any(t=>t.name=="Highlighted");
            img.color=highlight?new Color(Teal.r,Teal.g,Teal.b,img.name=="Background"?.22f:.7f):new Color(.08f,.16f,.20f,.9f);
        }
        target.gameObject.AddComponent<HearthReachControl>().Configure(manager);
        go.SetActive(true);
        var source=target.GetComponent<Image>();if(source!=null)source.color=new Color(1,1,1,0);
    }
}
#endif
