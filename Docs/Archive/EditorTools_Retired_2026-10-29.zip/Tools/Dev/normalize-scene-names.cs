// Run through unity-mcp code execute in SampleScene Edit Mode.
var scene=UnityEngine.SceneManagement.SceneManager.GetActiveScene();
if(scene.path!="Assets/Scenes/SampleScene.unity"||EditorApplication.isPlayingOrWillChangePlaymode)
 throw new System.InvalidOperationException("Open SampleScene in Edit Mode.");
var names=new System.Collections.Generic.Dictionary<string,string>{
 {"outdoor","OutdoorProps"},{"unity5","EnvironmentSource_Unity5"},
 {"dikuai (1)","CityLot_Secondary"},{"地块","CityLot_Offset"}
};
var roots=scene.GetRootGameObjects();
var changes=new System.Collections.Generic.List<object>();
Undo.IncrementCurrentGroup();var group=Undo.GetCurrentGroup();
Undo.SetCurrentGroupName("Normalize HEARTH environment root names");
foreach(var pair in names){
 var matches=roots.Where(r=>r.name==pair.Key).ToArray();
 if(matches.Length==0)continue;
 if(matches.Length!=1||roots.Any(r=>r.name==pair.Value))throw new System.InvalidOperationException("Ambiguous root: "+pair.Key);
 var go=matches[0];Undo.RecordObject(go,"Rename environment root");
 var oldName=go.name;go.name=pair.Value;
 if(PrefabUtility.IsPartOfPrefabInstance(go))PrefabUtility.RecordPrefabInstancePropertyModifications(go);
 changes.Add(new{instanceId=go.GetInstanceID(),originalName=oldName,newName=go.name});
}
Undo.CollapseUndoOperations(group);
if(changes.Count>0)UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(scene);
return new{changes=changes,dirty=scene.isDirty};
